Github Pages Link: https://itas666.github.io/MobileWebDev/Courseworks/vuejsTest.html

Github Repo (branch Individual): https://github.com/itas666/MobileWebDev/tree/Individual